import React from "react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";

const PublicLandingPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  const handleLanguageChange = (lang: string) => {
    i18n.changeLanguage(lang);
    localStorage.setItem("gusto-language", lang);
  };

  return (
    <div
      className="relative min-h-screen flex flex-col bg-cover bg-center text-content-title"
      style={{
        backgroundImage:
          "url('https://vehqvqlbtotljstixklz.supabase.co/storage/v1/object/public/Brand/Background%20v2.jpg')",
      }}
    >
      {/* Overlay sombre */}
      <div className="absolute inset-0 bg-black/50"></div>

      {/* Contenu principal */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6 py-12">
        <div className="max-w-3xl w-full">

          {/* Logo */}
          <img
            src="https://vehqvqlbtotljstixklz.supabase.co/storage/v1/object/public/Brand/logo%20KM.jpg"
            alt="King Menu Logo"
            className="mx-auto w-32 h-32 rounded-full shadow-soft mb-6 object-cover"
          />

          {/* Titre principal */}
          <h1 className="text-4xl md:text-5xl font-bold text-white drop-shadow-soft mb-4">
            {t("landing.title")}
          </h1>

          {/* Sous-titre */}
          <p className="text-lg md:text-xl text-gray-100 mb-8 leading-relaxed">
            {t("landing.subtitle")}
          </p>

          {/* Bloc des fonctionnalités */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-6 text-gray-100 mb-10 shadow-soft">
            <h2 className="text-2xl font-semibold mb-4">{t("landing.featuresTitle")}</h2>
            <ul className="space-y-2 text-left mx-auto max-w-md">
              <li>🍲 {t("landing.featureRecipes")}</li>
              <li>🥕 {t("landing.featureIngredients")}</li>
              <li>📅 {t("landing.featurePlanner")}</li>
              <li>🛒 {t("landing.featureShoppingList")}</li>
            </ul>
          </div>

          {/* Bouton Connexion */}
          <button
            onClick={() => navigate("/login")}
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-full font-semibold shadow-soft transition-transform transform hover:scale-105"
          >
            {t("landing.loginButton")}
          </button>

          {/* Sélecteur de langue */}
          <div className="mt-10 flex justify-center gap-3 flex-wrap">
            {["en", "fr", "es", "it", "ar"].map((lang) => (
              <button
                key={lang}
                onClick={() => handleLanguageChange(lang)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  i18n.language === lang
                    ? "bg-yellow-500 text-white"
                    : "bg-white/20 text-gray-200 hover:bg-white/40"
                }`}
              >
                {lang.toUpperCase()}
              </button>
            ))}
          </div>

        </div>
      </main>

      {/* Footer dans le flux normal — jamais superposé */}
      <footer className="relative z-10 text-content-hint text-sm flex flex-col items-center gap-2 py-6 px-4 bg-black/30">
        <div className="flex gap-4">
          <a href="/KingMenu/privacy-policy.html" className="hover:text-white underline">
            Privacy Policy
          </a>
          <a href="/KingMenu/terms-of-use.html" className="hover:text-white underline">
            Terms of Use
          </a>
        </div>
        <span>© {new Date().getFullYear()} King Menu — {t("landing.footer")}</span>
      </footer>
    </div>
  );
};

export default PublicLandingPage;
